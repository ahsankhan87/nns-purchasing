<!-- BEGIN PAGE CONTENT-->
<div class="row">
	<div class="col-md-12 page-500">
		<div class=" number">
			 500
		</div>
		<div class=" details">
			<h3>Oops! Something went wrong.</h3>
			<p>
				 You are not allowed to access this module.<br/>
				Please contact your administrator if any issue.<br/><br/>
			</p>
		</div>
	</div>
</div>
<!-- END PAGE CONTENT-->